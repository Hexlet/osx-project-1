//
//  main.m
//  DNA
//
//  Created by Stan Buran on 10/31/12.
//  Copyright (c) 2012 Stan Buran. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cell.h"

@interface Cell (Mutator)
    -(void) mutate : (int) value;
@end
@implementation Cell (Mutator)
    -(void) mutate : (int) value
    {
        //Declare some array that will contain the indices of dnaArray.
        //It will help to perform randomized changes without repeats
        NSMutableArray *tempArray = [[NSMutableArray alloc] init];
        for(int i = 0;i<100;i++)
            [tempArray addObject: [NSNumber numberWithInteger:i]];
        
        //замена значений по заданному количеству раз, исключая повторения:
        for(int i=0;i<value;i++)
        {
            //get random index from temp-array:
            int idx = arc4random() % [tempArray count];
            
            //get index of dnaArray which will be replaced
            int idxVal  =  (int) [[tempArray objectAtIndex:idx] integerValue];
            
            //get replacing char from dnaArray:
            NSString *oldChar= [NSString stringWithString: [[self dnaArray] objectAtIndex:idxVal]];

            //get new character, excluding replacing char:
            NSString *newChar = [self getRandomChar: oldChar];
            
            //replace old character with new one:
            [[self dnaArray] replaceObjectAtIndex:idxVal withObject: newChar];
            
            //to reduce repeats delete used index from the temp-array:
            [tempArray removeObjectAtIndex:idx];
        }
    }
@end

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //создаем два объекта класса Cell:
        Cell *dna1 = [[Cell alloc] init];
        Cell *dna2 = [[Cell alloc] init];
        
        //меряем:
        int intDist =[dna1 hammingDistance: dna2];
        
        //выводим на экран:
        [Cell printDetailedInfo: dna1 : dna2];
        printf("\nPrimary distance:%d\n", intDist);
        
        //мутируем десяток раз и смотрим что происходит:
        for(int i=10; i<=100; i+=10)
        {
            //учиняем мутацию объектам класса Cell:
            [dna1 mutate:i];
            [dna2 mutate:i];
        
            //снова меряем:
            intDist =[dna1 hammingDistance: dna2];
        
            //выводим на экран:
            printf("Distance after mutation %d%%: %d\n",i, intDist);
        }
        //и еще раз выводим на экран:
        [Cell printDetailedInfo: dna1 : dna2];
    }
    return 0;
}
