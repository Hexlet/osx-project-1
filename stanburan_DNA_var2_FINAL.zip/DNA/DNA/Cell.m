//
//  Cell.m
//  DNA
//
//  Created by Stan Buran on 10/31/12.
//  Copyright (c) 2012 Stan Buran. All rights reserved.
//

#import "Cell.h"

@implementation Cell

-(id) init
{
    self = [super init];
    if(self)
    {
        _dnaArray = [[NSMutableArray alloc] init];
        for(int i=0;i<100;i++)
           [_dnaArray addObject: self.getRandomChar];
    }
    return self;
}

-(int) hammingDistance : (Cell*) cell
{
    int iDist = 0;
    for(int i=0;i<100;i++)
    {
        NSString *strVal1 = [self.dnaArray objectAtIndex:i];
        NSString *strVal2 = [cell.dnaArray objectAtIndex:i];
        
        if(strVal1 != strVal2)
            iDist++;
    }
    return iDist;
}

-(NSString*) getRandomChar
{
    unichar chr = [@"ATGC" characterAtIndex:arc4random() % 4]; //random() % 4;
    return [NSString stringWithCharacters:&chr length:1];
}
-(NSString*) getRandomChar : (NSString*) excludeChar
{    
    NSString* strVal;
    
    if(excludeChar == @"A")
        strVal = @"TGC";
    else if (excludeChar == @"T")
        strVal = @"AGC";
    else if (excludeChar == @"G")
        strVal = @"ATC";
    else if (excludeChar == @"C")
        strVal = @"ATG";
    else
        strVal = @"ATGC";
    
    unichar chr = [strVal characterAtIndex:arc4random() % 4]; //random() % 4;
    return [NSString stringWithCharacters:&chr length:1];
}
+(void) printDetailedInfo : (Cell *) dna1 : (Cell *) dna2
{
    NSMutableArray *markerArray = [[NSMutableArray alloc] init];
    
    for(int i=0; i<100; i++)
    {
        NSString *strVal1 = [dna1.dnaArray objectAtIndex:i];
        NSString *strVal2 = [dna2.dnaArray objectAtIndex:i];
        
        if(strVal1 != strVal2)
            [markerArray addObject: @" "];
        else
            [markerArray addObject: @"⇣"];
    }
    
    [self printArray: markerArray];
    [self printArray: dna1.dnaArray];
    [self printArray: dna2.dnaArray];
}
+(void) printArray : (NSMutableArray *) array
{
    NSString * result = [[array valueForKey:@"description"] componentsJoinedByString:@""];
    printf("%s", [result UTF8String]);
    printf("\n");
}
@end
