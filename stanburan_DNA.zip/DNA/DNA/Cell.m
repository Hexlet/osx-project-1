//
//  Cell.m
//  DNA
//
//  Created by Stan Buran on 10/31/12.
//  Copyright (c) 2012 Stan Buran. All rights reserved.
//

#import "Cell.h"

@implementation Cell

-(id) init
{
    self = [super init];
    if(self)
    {
        _dnaArray = [[NSMutableArray alloc] init];
        for(int i=0;i<100;i++)
           [_dnaArray addObject: self.getRandomChar];
    }
    return self;
}

-(int) hammingDistance : (Cell*) cell
{
    int iDist = 0;
    for(int i=0;i<100;i++)
    {
        NSString *strVal1 = [self.dnaArray objectAtIndex:i];
        NSString *strVal2 = [cell.dnaArray objectAtIndex:i];
        
        if(strVal1 != strVal2)
            iDist++;
    }
    return iDist;
}

-(NSString*) getRandomChar
{
    unichar chr = [@"ATGC" characterAtIndex:arc4random() % 4]; //random() % 4;
    return [NSString stringWithCharacters:&chr length:1];
}
-(NSString*) getRandomChar : (NSString*) excludeChar
{
    //Пока еще не знаю всех возможностей языка, так что приходится есть яблоки вилкой.. :)
    
    NSString* strVal;
    
    if(excludeChar == @"A")
        strVal = @"TGC";
    else if (excludeChar == @"T")
        strVal = @"AGC";
    else if (excludeChar == @"G")
        strVal = @"ATC";
    else if (excludeChar == @"C")
        strVal = @"ATG";
    else
        strVal = @"ATGC";
    
    unichar chr = [strVal characterAtIndex:arc4random() % 4]; //random() % 4;
    return [NSString stringWithCharacters:&chr length:1];
}
@end
