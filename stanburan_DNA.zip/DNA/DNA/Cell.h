//
//  Cell.h
//  DNA
//
//  Created by Stan Buran on 10/31/12.
//  Copyright (c) 2012 Stan Buran. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cell : NSObject
    @property  NSMutableArray  *dnaArray;
    -(int) hammingDistance: (Cell*) cell;
    -(NSString*)getRandomChar: (NSString*) excludeVal;
@end
